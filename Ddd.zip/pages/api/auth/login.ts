import type { NextApiRequest, NextApiResponse } from 'next'
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import { query } from '../../../lib/db'
import dotenv from 'dotenv'
dotenv.config()

export default async function handler(req: NextApiRequest, res: NextApiResponse){
  if(req.method !== 'POST') return res.status(405).end()
  const { email, password } = req.body
  const r = await query('SELECT id, password_hash, role FROM users WHERE email=$1', [email])
  if(r.rowCount===0) return res.status(401).json({ error: 'Invalid credentials' })
  const u = r.rows[0]
  const ok = await bcrypt.compare(password, u.password_hash)
  if(!ok) return res.status(401).json({ error: 'Invalid credentials' })
  const token = jwt.sign({ userId: u.id, role: u.role }, process.env.JWT_SECRET || 'dev', { expiresIn: '7d' })
  res.json({ token })
}
