import type { NextApiRequest, NextApiResponse } from 'next'
import { query } from '../../../lib/db'
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import dotenv from 'dotenv'
dotenv.config()

function getUserFromAuth(req:NextApiRequest){
  const auth = req.headers.authorization
  if(!auth) return null
  try{
    const token = auth.split(' ')[1]
    return jwt.verify(token, process.env.JWT_SECRET || 'dev') as any
  }catch{ return null }
}

export default async function handler(req: NextApiRequest, res: NextApiResponse){
  const user = getUserFromAuth(req)
  if(!user) return res.status(401).json({error:'Unauthorized'})
  if(req.method === 'GET'){
    if(user.role !== 'admin') return res.status(403).json({error:'Forbidden'})
    const r = await query("SELECT u.id, u.email, u.name, u.phone, d.assigned_vehicle_id FROM users u LEFT JOIN drivers d ON u.id = d.user_id WHERE u.role='driver' ORDER BY u.name")
    return res.json(r.rows)
  }
  if(req.method === 'POST'){
    if(user.role !== 'admin') return res.status(403).json({error:'Forbidden'})
    const { name, email, phone, password } = req.body
    const hash = await bcrypt.hash(password || 'changeme', 10)
    const r = await query("INSERT INTO users (email, password_hash, role, name, phone) VALUES ($1,$2,$3,$4,$5) RETURNING id",[email, hash, 'driver', name, phone])
    return res.json({id: r.rows[0].id})
  }
  res.status(405).end()
}
