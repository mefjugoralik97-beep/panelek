import type { NextApiRequest, NextApiResponse } from 'next'
import { query } from '../../../../lib/db'
import jwt from 'jsonwebtoken'
import dotenv from 'dotenv'
dotenv.config()

function getUserFromAuth(req:NextApiRequest){
  const auth = req.headers.authorization
  if(!auth) return null
  try{
    const token = auth.split(' ')[1]
    return jwt.verify(token, process.env.JWT_SECRET || 'dev') as any
  }catch{ return null }
}

export default async function handler(req: NextApiRequest, res: NextApiResponse){
  const user = getUserFromAuth(req)
  if(!user) return res.status(401).json({error:'Unauthorized'})
  if(req.method !== 'PUT') return res.status(405).end()
  const { id } = req.query
  const { status } = req.body
  // basic rule: allow if admin or within 24h of pickup_time
  const t = await query('SELECT pickup_time FROM transfers WHERE id=$1',[id])
  if(t.rowCount===0) return res.status(404).json({error:'Not found'})
  const pickup = t.rows[0].pickup_time
  const now = new Date()
  const pickDate = new Date(pickup)
  const diff = now.getTime() - pickDate.getTime()
  const within24h = diff <= 24*60*60*1000
  if(user.role !== 'admin' && !within24h) return res.status(403).json({error:'Edit window expired'})
  await query('UPDATE transfers SET status=$1, updated_at=now() WHERE id=$2',[status, id])
  res.json({ok:true})
}
